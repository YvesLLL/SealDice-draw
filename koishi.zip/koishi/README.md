# Koishi 模板仓库

本仓库包含了 Koishi 的模板项目。

## 使用教程

<https://koishi.chat/manual/starter/boilerplate.html>
